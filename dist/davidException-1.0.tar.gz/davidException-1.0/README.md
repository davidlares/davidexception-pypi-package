# davidException

  A simple PyPi package for validating tinyInt range value with Python3 (custom Exception)

  TinyInt datatype:  > 0 <= 256

## Usage

```
  from tinyinterror import tiny_int_eval
  print(tiny_int_eval(400))

```

## Credits

   - [David E Lares S](https://twitter.com/@davidlares3)

## License

   - [MIT](https://opensource.org/licenses/MIT)
