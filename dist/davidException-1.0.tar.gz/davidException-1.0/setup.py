import setuptools

setuptools.setup(
    name = "davidException",
    packages = ["package"],
    version = "1.0",
    description = "A simple PyPi package for validating tinyInt range value with Python3",
    author = "David E Lares S",
    author_email = "david.e.lares@gmail.com",
    url = "https://upload.pypi.org/legacy/"
)
